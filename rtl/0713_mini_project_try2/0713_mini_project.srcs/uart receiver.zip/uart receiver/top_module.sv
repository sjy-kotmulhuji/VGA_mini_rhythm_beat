`timescale 1ns / 1ps

module top_game (
    input  logic        clk,
    input  logic        reset,
    input  logic [ 1:0] music_sel,
    input  logic        v_sync,
    input  logic [ 3:0] region,
    input  logic [ 2:0] main_state,
    //PC에서 받는 노트 lane 정보
    input  logic [ 3:0] lane_data,
    input  logic        note_start,
    // output logic [ 3:0] o_lane,
    output logic [11:0] o_duration,
    output logic [23:0] score,
    // [원래 코드 백업 (사용자 수정 시 perfect, good, miss, combo, fever 아웃풋 포트가 누락되어 판정이 막히는 문제 발생)]
    // );
    output logic        perfect,
    output logic        good,
    output logic        miss,
    output logic [ 9:0] combo,
    output logic        fever,
    // [추가] 새 카메라 모듈의 노트 렌더링용 실시간 Y좌표 출력 포트
    output logic [ 3:0] o_pos0,
    output logic [ 3:0] o_pos1,
    output logic [ 3:0] o_pos2,
    output logic [ 3:0] o_pos3,
    output logic [ 9:0] o_lcnt0,
    output logic [ 9:0] o_lcnt1,
    output logic [ 9:0] o_lcnt2,
    output logic [ 9:0] o_lcnt3
);

    logic [31:0] note_data;
    logic note_done;
    logic [3:0] w_rom_lane; // [추가] 곡 리더기가 읽어온 정적 노트 레인을 임시 보관할 와이어

    // [원래 코드 백업 (사용자 수정 시 perfect, good, miss, combo_done, fever가 내부 와이어로만 선언됨)]
    // logic perfect, good, miss, combo_done, fever;
    logic combo_done;
    logic [9:0] combo_data;

    assign combo = combo_data;

    //game reset
    logic game_reset;
    assign game_reset = reset || (main_state != 3'b011);    //GAME_CONT 상태가 아닐 때 rom 초기화

    // =========================================================================
    // [추가] v_sync 공용 글리치 필터 (100MHz 기준 10us = 1000클락 동안 유지될 때만 신호 인정)
    // UART 고속 시리얼 통신이 돌아갈 때 동기 신호선에 침투하는 물리 노이즈를 걸러내어
    // 프레임 카운트가 비정상적으로 치솟고 조기 종료(튕김)되는 결함을 방지합니다.
    // =========================================================================
    //logic [9:0] vs_filter_cnt;
    //logic       v_sync_clean;

    //
    //    always_ff @(posedge clk or posedge reset) begin
    //        if (reset) begin
    //            vs_filter_cnt <= '0;
    //            v_sync_clean  <= 1'b1; // Active-Low idle 상태
    //        end else begin
    //            if (v_sync == v_sync_clean) begin
    //                vs_filter_cnt <= '0;
    //            end else begin
    //                if (vs_filter_cnt == 10'd1000) begin
    //                    v_sync_clean  <= v_sync;
    //                    vs_filter_cnt <= '0;
    //                end else begin
    //                    vs_filter_cnt <= vs_filter_cnt + 1'b1;
    //                end
    //            end
    //        end
    //    end


    line_count U_LINE_COUNT (
        .clk    (clk),
        .reset  (game_reset),
        .i_note (note_start),
        .i_lane (lane_data),   // i_lane 에 w_rom_lane 매핑
        // [원래 코드 백업 (사용자 수정 시 필터링 안 된 v_sync가 직접 매핑되어 노트 텔레포트 유발)]
        .i_vs   (v_sync),
        //.i_vs   (v_sync_clean),
        .o_pos0 (o_pos0),
        .o_lcnt0(o_lcnt0),
        .o_pos1 (o_pos1),
        .o_lcnt1(o_lcnt1),
        .o_pos2 (o_pos2),
        .o_lcnt2(o_lcnt2),
        .o_pos3 (o_pos3),
        .o_lcnt3(o_lcnt3)
    );

    GameResult U_GAMERESULT (
        .clk       (clk),
        // [원래 코드 백업 (사용자 수정 시 대기상태 판정기 리셋 방지 누락)]
        // .reset     (reset),
        .reset     (game_reset),
        .pos0      (o_pos0),
        .pos1      (o_pos1),
        .pos2      (o_pos2),
        .pos3      (o_pos3),
        .lcnt0     (o_lcnt0),
        .lcnt1     (o_lcnt1),
        .lcnt2     (o_lcnt2),
        .lcnt3     (o_lcnt3),
        .region    (region),
        // [원래 코드 백업 (사용자 수정 시 필터링 안 된 v_sync가 직접 매핑되어 판정 마스크 꼬임 유발)]
        .v_sync    (v_sync),
        //.v_sync    (v_sync_clean),
        .perfect   (perfect),
        .good      (good),
        .miss      (miss),
        .combo_done(combo_done),
        // [원래 코드 백업 (사용자 수정 시 combo_data 핀에 오타 combd_data가 매핑되어 컴파일 에러 발생)]
        // .combo_data(combd_data),
        .combo_data(combo_data),
        .fever     (fever)
        // .o_lane    (o_lane)  // [추가] 실시간 조합된 노트 X좌표를 모듈 밖으로 출력
    );

    score U_SCORE (
        .clk       (clk),
        .reset     (reset),
        .main_state(main_state),
        .good      (good),
        .perfect   (perfect),
        .miss      (miss),
        .combo_done(combo_done),
        .combo_data(combo_data),
        .fever     (fever),
        .score     (score)
    );

endmodule
